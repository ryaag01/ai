#!/bin/bash
echo Setup script